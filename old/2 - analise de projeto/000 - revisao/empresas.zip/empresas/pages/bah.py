import streamlit as st
from funcoes.entradas import obter_nome_qtd_empresa

if st.button("voltar para a pagina inicial"):
    st.switch_page("main.py")  # Nome do arquivo da página


